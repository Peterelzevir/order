//order func
const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData, writeData, addTransaction } = require('../helpers/fileHelper');

const handleOrder = async (ctx) => {
    try {
        await ctx.reply(
            '╔═══════════════════╗\n' +
            '║    🛍️ ORDER     ║\n' +
            '╚═══════════════════╝\n\n' +
            '*Masukkan ID Layanan:*\n' +
            'Ketik /cancel untuk membatalkan',
            { parse_mode: 'Markdown' }
        );

        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        user.state = 'AWAITING_SERVICE_ID';
        writeData(data);
    } catch (error) {
        return ctx.reply('❌ Gagal memulai order. Silahkan coba lagi.');
    }
};

const handleOrderServiceId = async (ctx) => {
    const serviceId = ctx.message.text;
    
    if (serviceId.toLowerCase() === '/cancel') {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        delete user.state;
        delete user.orderData;
        writeData(data);
        
        return ctx.reply(
            '✅ Order dibatalkan.',
            Markup.inlineKeyboard([[
                Markup.button.callback('🔙 Kembali ke Menu', 'back')
            ]])
        );
    }

    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        const service = response.data.data.find(s => s.id === parseInt(serviceId));
        if (!service) {
            return ctx.reply(
                '❌ ID Layanan tidak valid!\n' +
                'Silahkan cek kembali ID layanan dengan perintah /list'
            );
        }

        const markup = (100 + config.margin) / 100;
        const adjustedPrice = service.price * markup;

        const message = 
            '╔═══════════════════╗\n' +
            '║   🛍️ LAYANAN    ║\n' +
            '╚═══════════════════╝\n\n' +
            `*${service.name}*\n\n` +
            `💰 Harga: Rp ${adjustedPrice.toLocaleString()}/1000\n` +
            `📊 Min: ${service.min}\n` +
            `📊 Max: ${service.max}\n` +
            `♻️ Refill: ${service.refill ? '✅' : '❌'}\n\n` +
            '*Masukkan jumlah pesanan:*\n' +
            'Ketik /cancel untuk membatalkan';

        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        user.state = 'AWAITING_QUANTITY';
        user.orderData = { 
            serviceId, 
            serviceName: service.name,
            price: adjustedPrice,
            min: service.min,
            max: service.max
        };
        writeData(data);

        return ctx.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
        return ctx.reply('❌ Gagal memproses ID layanan. Silahkan coba lagi.');
    }
};

const handleOrderQuantity = async (ctx) => {
    const quantity = parseInt(ctx.message.text);
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);
    
    if (!user.orderData) {
        return ctx.reply(
            '❌ Sesi order telah kedaluwarsa.\n' +
            'Silahkan mulai ulang dengan perintah /order'
        );
    }

    if (isNaN(quantity)) {
        return ctx.reply('❌ Jumlah harus berupa angka!');
    }

    if (quantity < user.orderData.min || quantity > user.orderData.max) {
        return ctx.reply(
            '❌ Jumlah tidak valid!\n' +
            `Minimum: ${user.orderData.min}\n` +
            `Maksimum: ${user.orderData.max}`
        );
    }

    // Calculate price (per 1000)
    const pricePerK = user.orderData.price / 1000;
    const totalPrice = pricePerK * quantity;
    
    if (user.balance < totalPrice) {
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║    ❌ GAGAL      ║\n' +
            '╚═══════════════════╝\n\n' +
            '📛 *Saldo Tidak Cukup*\n\n' +
            `Harga: Rp ${totalPrice.toLocaleString()}\n` +
            `Saldo: Rp ${user.balance.toLocaleString()}\n\n` +
            'Silahkan deposit terlebih dahulu.',
            { 
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('💎 Deposit', 'deposit')
                ]])
            }
        );
    }

    try {
        const response = await axios.post('https://api.medanpedia.co.id/order', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service: user.orderData.serviceId,
            quantity
        });

        if (response.data.status) {
            // Update user balance
            user.balance -= totalPrice;
            
            // Add to transaction history
            addTransaction(user.id, 'order', -totalPrice, 
                `Order ${user.orderData.serviceName} (${quantity})`);
            
            // Store order history
            if (!user.orders) user.orders = [];
            user.orders.push({
                id: response.data.data.id,
                serviceId: user.orderData.serviceId,
                serviceName: user.orderData.serviceName,
                quantity,
                price: totalPrice,
                date: new Date().toISOString()
            });

            delete user.state;
            delete user.orderData;
            writeData(data);

            return ctx.reply(
                '╔═══════════════════╗\n' +
                '║   ✅ BERHASIL    ║\n' +
                '╚═══════════════════╝\n\n' +
                `*Order ID:* #${response.data.data.id}\n` +
                `*Layanan:* ${user.orderData.serviceName}\n` +
                `*Jumlah:* ${quantity}\n` +
                `*Total:* Rp ${totalPrice.toLocaleString()}\n` +
                `*Sisa Saldo:* Rp ${user.balance.toLocaleString()}\n\n` +
                '🔍 Cek status pesanan dengan perintah /riwayat',
                { 
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[
                        Markup.button.callback('🔙 Kembali ke Menu', 'back')
                    ]])
                }
            );
        } else {
            throw new Error(response.data.msg);
        }
    } catch (error) {
        let errorMessage = '';
        if (error.response && error.response.data && error.response.data.msg === 'Saldo Anda tidak mencukupi untuk melakukan pemesanan ini.') {
            return ctx.reply(
                '❌ Saldo server tidak mencukupi\n' +
                `Silahkan hubungi admin @${config.csUsername}`
            );
        }
        return ctx.reply(
            '❌ Gagal memproses pesanan\n' +
            'Silahkan coba lagi atau hubungi admin'
        );
    }
};

module.exports = {
    handleOrder,
    handleOrderServiceId,
    handleOrderQuantity
};