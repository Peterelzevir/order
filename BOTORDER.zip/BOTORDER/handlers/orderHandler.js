const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData, writeData, addTransaction } = require('../helpers/fileHelper');

const handleOrder = async (ctx) => {
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    if (!user) {
        return ctx.reply('⚠️ Anda belum terdaftar. Silakan gunakan /start terlebih dahulu.');
    }

    try {
        await ctx.reply(
            '╔═══════════════════╗\n' +
            '║    🛍️ ORDER     ║\n' +
            '╚═══════════════════╝\n\n' +
            '*Masukkan ID Layanan:*\n' +
            'Ketik /cancel untuk membatalkan',
            { parse_mode: 'Markdown' }
        );

        user.state = 'AWAITING_SERVICE_ID';
        writeData(data);
    } catch (error) {
        console.error('Error in handleOrder:', error);
        return ctx.reply('❌ Gagal memulai order. Silahkan coba lagi.');
    }
};

const handleOrderServiceId = async (ctx) => {
    if (ctx.message.text.toLowerCase() === '/cancel') {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        delete user.state;
        delete user.orderData;
        writeData(data);
        
        return ctx.reply(
            '✅ Order dibatalkan.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🔙 Kembali ke Menu', 'back')
                ]])
            }
        );
    }

    try {
        const serviceId = ctx.message.text;
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        if (!response.data.status) {
            throw new Error(response.data.msg || 'Failed to fetch services');
        }

        const service = response.data.data.find(s => s.id === parseInt(serviceId));
        if (!service) {
            return ctx.reply(
                '❌ ID Layanan tidak valid!\n' +
                'Silahkan cek kembali ID layanan dengan perintah /list',
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[
                        Markup.button.callback('📋 Lihat Layanan', 'list')
                    ]])
                }
            );
        }

        const markup = (100 + config.margin) / 100;
        const adjustedPrice = service.price * markup;

        const message = 
            '╔═══════════════════╗\n' +
            '║   🛍️ LAYANAN    ║\n' +
            '╚═══════════════════╝\n\n' +
            `*${service.name}*\n\n` +
            `💰 Harga: Rp ${adjustedPrice.toLocaleString()}/1000\n` +
            `📊 Min: ${service.min}\n` +
            `📊 Max: ${service.max}\n` +
            `♻️ Refill: ${service.refill ? '✅' : '❌'}\n\n` +
            '*Masukkan jumlah pesanan:*\n' +
            'Ketik /cancel untuk membatalkan';

        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        user.state = 'AWAITING_QUANTITY';
        user.orderData = { 
            serviceId, 
            serviceName: service.name,
            price: adjustedPrice,
            min: service.min,
            max: service.max
        };
        writeData(data);

        return ctx.reply(message, { parse_mode: 'Markdown' });
    } catch (error) {
        console.error('Error in handleOrderServiceId:', error);
        return ctx.reply(
            '❌ Gagal memproses ID layanan. Silahkan coba lagi.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🔙 Kembali', 'back')
                ]])
            }
        );
    }
};

const handleOrderQuantity = async (ctx) => {
    if (ctx.message.text.toLowerCase() === '/cancel') {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        delete user.state;
        delete user.orderData;
        writeData(data);
        
        return ctx.reply(
            '✅ Order dibatalkan.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🔙 Kembali ke Menu', 'back')
                ]])
            }
        );
    }

    const quantity = parseInt(ctx.message.text);
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);
    
    if (!user.orderData) {
        return ctx.reply(
            '❌ Sesi order telah kedaluwarsa.\n' +
            'Silahkan mulai ulang dengan perintah /order',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🛍️ Order Baru', 'order')
                ]])
            }
        );
    }

    if (isNaN(quantity)) {
        return ctx.reply('❌ Jumlah harus berupa angka!');
    }

    if (quantity < user.orderData.min || quantity > user.orderData.max) {
        return ctx.reply(
            '❌ Jumlah tidak valid!\n' +
            `Minimum: ${user.orderData.min}\n` +
            `Maksimum: ${user.orderData.max}`
        );
    }

    user.orderData.quantity = quantity;
    user.state = 'AWAITING_TARGET';
    writeData(data);

    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   🎯 TARGET     ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Masukkan target:*\n' +
        'Contoh: username/link\n' +
        'Ketik /cancel untuk membatalkan',
        { parse_mode: 'Markdown' }
    );
};

const handleOrderTarget = async (ctx) => {
    if (ctx.message.text.toLowerCase() === '/cancel') {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        delete user.state;
        delete user.orderData;
        writeData(data);
        
        return ctx.reply(
            '✅ Order dibatalkan.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🔙 Kembali ke Menu', 'back')
                ]])
            }
        );
    }

    const target = ctx.message.text;
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    if (!user.orderData) {
        return ctx.reply(
            '❌ Sesi order telah kedaluwarsa.\n' +
            'Silahkan mulai ulang dengan perintah /order'
        );
    }

    const pricePerK = user.orderData.price / 1000;
    const totalPrice = pricePerK * user.orderData.quantity;

    user.orderData.target = target;
    user.state = 'AWAITING_CONFIRMATION';
    writeData(data);

    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   📋 KONFIRMASI   ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Detail Pesanan:*\n' +
        `📦 Layanan: ${user.orderData.serviceName}\n` +
        `🎯 Target: ${target}\n` +
        `📊 Jumlah: ${user.orderData.quantity}\n` +
        `💰 Total: Rp ${totalPrice.toLocaleString()}\n` +
        `💳 Saldo: Rp ${user.balance.toLocaleString()}\n\n` +
        'Silahkan konfirmasi pesanan Anda:',
        {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [
                    Markup.button.callback('✅ Konfirmasi', 'confirm_order'),
                    Markup.button.callback('❌ Batal', 'cancel_order')
                ]
            ])
        }
    );
};

const handleOrderConfirmation = async (ctx) => {
    try {
        // Try to delete the previous message first
        try {
            await ctx.deleteMessage();
        } catch (deleteError) {
            console.log('Could not delete message:', deleteError);
        }

        console.log('Starting order confirmation process');
        console.log('Context:', JSON.stringify({
            from: ctx.from,
            chat: ctx.chat,
            callbackQuery: ctx.callbackQuery
        }, null, 2));
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);

        if (!user || !user.orderData) {
            return ctx.reply(
                '❌ Sesi order telah kedaluwarsa.\n' +
                'Silahkan mulai ulang dengan perintah /order',
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[
                        Markup.button.callback('🛍️ Order Baru', 'order')
                    ]])
                }
            );
        }

        const pricePerK = user.orderData.price / 1000;
        const totalPrice = pricePerK * user.orderData.quantity;

        if (user.balance < totalPrice) {
            return ctx.reply(
                '╔═══════════════════╗\n' +
                '║    ❌ GAGAL      ║\n' +
                '╚═══════════════════╝\n\n' +
                '📛 *Saldo Tidak Cukup*\n\n' +
                `Harga: Rp ${totalPrice.toLocaleString()}\n` +
                `Saldo: Rp ${user.balance.toLocaleString()}\n\n` +
                'Silahkan deposit terlebih dahulu.',
                { 
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[
                        Markup.button.callback('💎 Deposit', 'deposit')
                    ]])
                }
            );
        }

        try {
            const response = await axios.post('https://api.medanpedia.co.id/order', {
                api_id: config.apiId,
                api_key: config.apiKey,
                service: user.orderData.serviceId,
                target: user.orderData.target,
                quantity: user.orderData.quantity
            });

            console.log('API Response:', response.data); // Debug log

            if (response.data && response.data.status === true) {
                // Success handling
            } else {
                throw new Error(response.data.msg || 'Order failed');
            }
        } catch (apiError) {
            console.error('API Error:', apiError);
            throw apiError;
        }

        // Update user balance
        user.balance -= totalPrice;
        
        // Add to transaction history
        addTransaction(user.id, 'order', -totalPrice, 
            `Order ${user.orderData.serviceName} (${user.orderData.quantity})`);
        
        // Store order history
        if (!user.orders) {
            user.orders = [];
        }
        
        user.orders.push({
            id: response.data.data.id,
            serviceId: user.orderData.serviceId,
            serviceName: user.orderData.serviceName,
            target: user.orderData.target,
            quantity: user.orderData.quantity,
            price: totalPrice,
            date: new Date().toISOString()
        });

        // Clear order state and data
        delete user.state;
        delete user.orderData;
        writeData(data);

        // Send success message
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║   ✅ BERHASIL    ║\n' +
            '╚═══════════════════╝\n\n' +
            `*Order ID:* #${response.data.data.id}\n` +
            `*Layanan:* ${user.orders[user.orders.length - 1].serviceName}\n` +
            `*Target:* ${user.orders[user.orders.length - 1].target}\n` +
            `*Jumlah:* ${user.orders[user.orders.length - 1].quantity}\n` +
            `*Total:* Rp ${totalPrice.toLocaleString()}\n` +
            `*Sisa Saldo:* Rp ${user.balance.toLocaleString()}\n\n` +
            '🔍 Cek status pesanan dengan perintah /riwayat',
            { 
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [
                        Markup.button.callback('📋 Riwayat', 'riwayat'),
                        Markup.button.callback('🛍️ Order Lagi', 'order')
                    ],
                    [Markup.button.callback('🔙 Menu Utama', 'back')]
                ])
            }
        );

    } catch (error) {
        console.error('Error in handleOrderConfirmation:', error);
        
        let errorMessage = '❌ Gagal memproses pesanan\n';
        
        // Check if it's an API error response
        if (error.response && error.response.data) {
            console.log('API Error Response:', error.response.data); // Debug log
            
            if (error.response.data.msg) {
                errorMessage = `❌ ${error.response.data.msg}\n`;
            }
        } else if (error.message) {
            errorMessage = `❌ ${error.message}\n`;
        }

        // Log the full error for debugging
        console.log('Full error object:', JSON.stringify(error, null, 2));
        
        return ctx.reply(
            errorMessage + 'Silahkan coba lagi atau hubungi admin.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([
                    [
                        Markup.button.callback('🔄 Coba Lagi', 'order'),
                        Markup.button.callback('👨‍💻 Hubungi Admin', 'cs')
                    ],
                    [Markup.button.callback('🔙 Menu Utama', 'back')]
                ])
            }
        );
    }
};

module.exports = {
    handleOrder,
    handleOrderServiceId,
    handleOrderQuantity,
    handleOrderTarget,
    handleOrderConfirmation
};