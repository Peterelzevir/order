// handlers/depositHandler.js
const { Markup } = require('telegraf');
const config = require('../config/config.json');

const handleDeposit = async (ctx) => {
    const text = ctx.message.text;
    const amount = text.split(' ')[1];

    if (!amount || isNaN(amount)) {
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║    💎 *DEPOSIT*    ║\n' +
            '╚═══════════════════╝\n\n' +
            '*Format Deposit:*\n' +
            '```/deposit <jumlah>```\n\n' +
            '*Contoh:*\n' +
            '```/deposit 50000```',
            { 
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🔙 Kembali', 'back')
                ]])
            }
        );
    }

    // Validate minimum deposit
    if (parseInt(amount) < config.minimumDeposit) {
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║    ⚠️ *GAGAL*    ║\n' +
            '╚═══════════════════╝\n\n' +
            `*Minimum Deposit: Rp ${config.minimumDeposit.toLocaleString()}*\n\n` +
            '*Format yang benar:*\n' +
            '```/deposit <jumlah>```\n\n' +
            '*Contoh:*\n' +
            `\`\`\`/deposit ${config.minimumDeposit}\`\`\``,
            { parse_mode: 'Markdown' }
        );
    }

    const message = 
        '╔═══════════════════╗\n' +
        '║    💎 *DEPOSIT*   ║\n' +
        '╚═══════════════════╝\n\n' +
        `*Jumlah Deposit:* Rp ${parseInt(amount).toLocaleString()}\n\n` +
        '*Silahkan hubungi admin untuk proses deposit:*\n' +
        `*👨‍💻 Admin:* @${config.csUsername}`;

    return ctx.reply(
        message,
        {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([[
                Markup.button.url('💬 Hubungi Admin', `https://t.me/${config.csUsername}`)
            ]])
        }
    );
};

module.exports = { handleDeposit };