const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData, writeData, getTransactionHistory } = require('../helpers/fileHelper');

const handleRiwayat = async (ctx) => {
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    if (!user || !user.orders || user.orders.length === 0) {
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║   📜 RIWAYAT    ║\n' +
            '╚═══════════════════╝\n\n' +
            'Belum ada riwayat pesanan.',
            {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard([[
                    Markup.button.callback('🛍️ Order Sekarang', 'order')
                ]])
            }
        );
    }

    try {
        let message = 
            '╔═══════════════════╗\n' +
            '║   📜 RIWAYAT    ║\n' +
            '╚═══════════════════╝\n\n';

        // Get status for last 10 orders
        for (const order of user.orders.slice(-10).reverse()) {
            try {
                const response = await axios.post('https://api.medanpedia.co.id/status', {
                    api_id: config.apiId,
                    api_key: config.apiKey,
                    id: order.id
                });

                if (response.data.status) {
                    const status = response.data.data;
                    message += 
                        `*Order #${order.id}*\n` +
                        `Layanan: ${order.serviceName}\n` +
                        `Status: ${getStatusEmoji(status.status)} ${status.status}\n` +
                        `Jumlah: ${order.quantity}\n` +
                        `Harga: Rp ${order.price.toLocaleString()}\n` +
                        `Progress: ${status.remains}/${status.start_count}\n` +
                        `Tanggal: ${new Date(order.date).toLocaleString()}\n\n`;
                }
            } catch (error) {
                message += 
                    `*Order #${order.id}*\n` +
                    `Layanan: ${order.serviceName}\n` +
                    `Status: ❓ Unknown\n` +
                    `Jumlah: ${order.quantity}\n` +
                    `Harga: Rp ${order.price.toLocaleString()}\n` +
                    `Tanggal: ${new Date(order.date).toLocaleString()}\n\n`;
            }
        }

        message += '🔍 Menampilkan 10 pesanan terakhir';

        return ctx.reply(message, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([[
                Markup.button.callback('🔙 Kembali', 'back')
            ]])
        });
    } catch (error) {
        return ctx.reply('❌ Gagal mengambil riwayat. Silahkan coba lagi.');
    }
};

const handleRefill = async (ctx) => {
    await ctx.reply(
        '╔═══════════════════╗\n' +
        '║    ♻️ REFILL    ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Masukkan ID pesanan:*\n' +
        'Ketik /cancel untuk membatalkan',
        { parse_mode: 'Markdown' }
    );

    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);
    user.state = 'AWAITING_REFILL_ID';
    writeData(data);
};

const handleRefillId = async (ctx) => {
    const orderId = ctx.message.text;
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    // Clear user state
    delete user.state;
    writeData(data);
    
    if (orderId.toLowerCase() === '/cancel') {
        return ctx.reply(
            '✅ Permintaan refill dibatalkan.',
            Markup.inlineKeyboard([[
                Markup.button.callback('🔙 Kembali ke Menu', 'back')
            ]])
        );
    }

    try {
        const response = await axios.post('https://api.medanpedia.co.id/refill', {
            api_id: config.apiId,
            api_key: config.apiKey,
            id_order: orderId
        });

        if (response.data.status) {
            return ctx.reply(
                '╔═══════════════════╗\n' +
                '║   ✅ BERHASIL    ║\n' +
                '╚═══════════════════╝\n\n' +
                `*Refill ID:* #${response.data.data.id_refill}\n\n` +
                'Permintaan refill berhasil dibuat.\n' +
                'Mohon tunggu proses refill selesai.',
                { 
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[
                        Markup.button.callback('🔙 Kembali', 'back')
                    ]])
                }
            );
        } else {
            throw new Error(response.data.msg);
        }
    } catch (error) {
        let errorMessage = 'Gagal memproses refill';
        if (error.response && error.response.data && error.response.data.msg) {
            errorMessage = error.response.data.msg;
        }
        return ctx.reply(
            '❌ ' + errorMessage + '\nSilahkan coba lagi atau hubungi admin'
        );
    }
};

const handleBalance = async (ctx) => {
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    // Get recent transactions
    const transactions = getTransactionHistory(ctx.from.id).slice(0, 5);
    let transactionText = '';
    
    if (transactions.length > 0) {
        transactionText = '\n\n*Transaksi Terakhir:*\n';
        transactions.forEach(trx => {
            const emoji = trx.type === 'deposit' ? '💎' : 
                         trx.type === 'order' ? '🛍️' : '💰';
            transactionText += `${emoji} ${trx.description}: Rp ${Math.abs(trx.amount).toLocaleString()}\n`;
        });
    }

    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   💰 SALDO      ║\n' +
        '╚═══════════════════╝\n\n' +
        `*Saldo Anda:* Rp ${user.balance.toLocaleString()}` +
        transactionText + '\n\n' +
        'Deposit saldo dengan perintah /deposit',
        { 
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.callback('💎 Deposit', 'deposit')],
                [Markup.button.callback('🔙 Kembali', 'back')]
            ])
        }
    );
};

const handleCS = async (ctx) => {
    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   👨‍💻 BANTUAN    ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Butuh bantuan? Hubungi customer service kami:*\n\n' +
        `Admin: @${config.csUsername}\n` +
        'Waktu Layanan: 09:00 - 21:00 WIB\n\n' +
        '✅ Fast Response\n' +
        '✅ Proses Cepat\n' +
        '✅ Trusted Admin',
        { 
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.url('💬 Chat Admin', `https://t.me/${config.csUsername}`)],
                [Markup.button.callback('🔙 Kembali', 'back')]
            ])
        }
    );
};

// Helper function untuk emoji status
const getStatusEmoji = (status) => {
    const emojis = {
        'Pending': '⏳',
        'Processing': '🔄',
        'Success': '✅',
        'Error': '❌',
        'Partial': '⚠️'
    };
    return emojis[status] || '❓';
};

// Helper function untuk format tanggal
const formatDate = (date) => {
    const d = new Date(date);
    return d.toLocaleString('id-ID', { 
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

// Export semua handler
module.exports = {
    handleRiwayat,
    handleRefill,
    handleRefillId,
    handleBalance,
    handleCS
};