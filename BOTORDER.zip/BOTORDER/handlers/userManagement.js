const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData, writeData, getTransactionHistory } = require('../helpers/fileHelper');
// Store user sessions globally
const userSessions = new Map();

const handleRiwayat = async (ctx, page = 0) => {
    try {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);

        if (!user || !user.orders || user.orders.length === 0) {
            return ctx.reply(
                '╔═══════════════════╗\n' +
                '║   📜 *RIWAYAT*    ║\n' +
                '╚═══════════════════╝\n\n' +
                '*👀 Belum ada riwayat pesanan*\n👉*kirim pesan* /order buat order',
                { parse_mode: 'Markdown' }
            );
        }

        const ordersPerPage = 5;
        const totalOrders = user.orders.length;
        const totalPages = Math.ceil(totalOrders / ordersPerPage);

        // Validate page number
        if (page < 0) page = 0;
        if (page >= totalPages) page = totalPages - 1;

        const startIdx = page * ordersPerPage;
        const endIdx = Math.min(startIdx + ordersPerPage, totalOrders);
        const recentOrders = user.orders.slice().reverse().slice(startIdx, endIdx);

        let message = 
            '╔═══════════════════╗\n' +
            '║   📜 *RIWAYAT*    ║\n' +
            '╚═══════════════════╝\n\n';

        // Fetch order statuses
        const statusPromises = recentOrders.map(order => 
            axios.post('https://api.medanpedia.co.id/status', {
                api_id: config.apiId,
                api_key: config.apiKey,
                id: order.id
            })
            .then(response => ({ order, status: response.data.data }))
            .catch(() => ({ order, status: null }))
        );

        const results = await Promise.all(statusPromises);

        results.forEach(({ order, status }) => {
            if (status) {
                message += 
                    `🔔 *Order #${order.id}*\n` +
                    `💡 Layanan: ${order.serviceName}\n` +
                    `✅ Status: ${getStatusEmoji(status.status)} ${status.status}\n` +
                    `👁‍🗨 Jumlah: ${order.quantity}\n` +
                    `💳 Harga: Rp ${order.price.toLocaleString()}\n` +
                    `❕ Progress: ${status.remains}/${status.start_count}\n` +
                    `👀 Tanggal: ${formatDate(order.date)}\n\n`;
            } else {
                message += 
                    `🔔 *Order #${order.id}*\n` +
                    `💡 Layanan: ${order.serviceName}\n` +
                    `✅ Status: ❓ Unknown\n` +
                    `👁‍🗨 Jumlah: ${order.quantity}\n` +
                    `💳 Harga: Rp ${order.price.toLocaleString()}\n` +
                    `👀 Tanggal: ${formatDate(order.date)}\n\n`;
            }
        });

        message += `📜 *Halaman ${page + 1} dari ${totalPages}*`;

        // Create navigation buttons
        const buttons = [];
        if (page > 0) {
            buttons.push(Markup.button.callback('⬅️ Sebelumnya', `riwayat_${page - 1}`));
        }
        if (endIdx < totalOrders) {
            buttons.push(Markup.button.callback('➡️ Lanjut', `riwayat_${page + 1}`));
        }
        buttons.push(Markup.button.callback('❌ Tutup', 'riwayat_tutup'));

        const msgOptions = {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([buttons])
        };

        // Handle message update vs new message
        const sentMessage = await ctx.reply(message, msgOptions);
        userSessions.set(ctx.from.id, sentMessage.message_id);

        return sentMessage;
    } catch (error) {
        console.error('Error in handleRiwayat:', error);
        return ctx.reply('❌ Terjadi kesalahan saat memuat riwayat. Silakan coba lagi.');
    }
};

// Add handler for riwayat navigation actions
const handleRiwayatAction = async (ctx, page) => {
    try {
        const messageId = userSessions.get(ctx.from.id);
        if (messageId) {
            await ctx.deleteMessage(messageId).catch(() => {});
        }
        await handleRiwayat(ctx, page);
        await ctx.answerCbQuery();
    } catch (error) {
        console.error('Error in handleRiwayatAction:', error);
        await ctx.answerCbQuery('❌ Terjadi kesalahan');
    }
};

// Add handler for riwayat close action
const handleRiwayatClose = async (ctx) => {
    try {
        const messageId = userSessions.get(ctx.from.id);
        if (messageId) {
            await ctx.deleteMessage(messageId);
            userSessions.delete(ctx.from.id);
        }
        await ctx.answerCbQuery('✅ Riwayat ditutup');
    } catch (error) {
        console.error('Error in handleRiwayatClose:', error);
        await ctx.answerCbQuery('❌ Terjadi kesalahan');
    }
};

const handleRefill = async (ctx) => {
    await ctx.reply(
        '╔═══════════════════╗\n' +
        '║    ♻️ *REFILL*    ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Masukkan ID pesanan:*\n' +
        'Ketik /cancel untuk membatalkan',
        { parse_mode: 'Markdown' }
    );

    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);
    user.state = 'AWAITING_REFILL_ID';
    writeData(data);
};

const handleRefillId = async (ctx) => {
    const orderId = ctx.message.text;
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    // Clear user state
    delete user.state;
    writeData(data);
    
    if (orderId.toLowerCase() === '/cancel') {
        return ctx.reply(
            '✅ Permintaan refill dibatalkan.',
            Markup.inlineKeyboard([[
                Markup.button.callback('🔙 Kembali ke Menu', 'back')
            ]])
        );
    }

    try {
        const response = await axios.post('https://api.medanpedia.co.id/refill', {
            api_id: config.apiId,
            api_key: config.apiKey,
            id_order: orderId
        });

        if (response.data.status) {
            return ctx.reply(
                '╔═══════════════════╗\n' +
                '║   ✅ *BERHASIL*    ║\n' +
                '╚═══════════════════╝\n\n' +
                `*Refill ID:* #${response.data.data.id_refill}\n\n` +
                '*Permintaan refill berhasil dibuat*\n' +
                '*Mohon tunggu proses refill selesai*',
                { 
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard([[
                        Markup.button.callback('🔙 Kembali', 'back')
                    ]])
                }
            );
        } else {
            throw new Error(response.data.msg);
        }
    } catch (error) {
        let errorMessage = 'Gagal memproses refill';
        if (error.response && error.response.data && error.response.data.msg) {
            errorMessage = error.response.data.msg;
        }
        return ctx.reply(
            '❌ ' + errorMessage + '\nSilahkan coba lagi atau hubungi admin'
        );
    }
};

const handleBalance = async (ctx) => {
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);

    // Get recent transactions
    const transactions = getTransactionHistory(ctx.from.id).slice(0, 5);
    let transactionText = '';
    
    if (transactions.length > 0) {
        transactionText = '\n\n*Transaksi Terakhir:*\n';
        transactions.forEach(trx => {
            const emoji = trx.type === 'deposit' ? '💎' : 
                         trx.type === 'order' ? '🛍️' : '💰';
            transactionText += `${emoji} ${trx.description}: Rp ${Math.abs(trx.amount).toLocaleString()}\n`;
        });
    }

    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   💰 *SALDO*      ║\n' +
        '╚═══════════════════╝\n\n' +
        `*Saldo Anda:* Rp ${user.balance.toLocaleString()}` +
        transactionText + '\n\n' +
        'Deposit saldo dengan perintah /deposit',
        { parse_mode: 'Markdown' }
    );
};

const handleCS = async (ctx) => {
    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   👨‍💻 *BANTUAN*    ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Butuh bantuan? Hubungi customer service kami:*\n\n' +
        `Admin: @${config.csUsername}\n` +
        'Waktu Layanan: 09:00 - 21:00 WIB\n\n' +
        '✅ Fast Response\n' +
        '✅ Proses Cepat\n' +
        '✅ Trusted Admin',
        { 
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard([
                [Markup.button.url('💬 Chat Admin', `https://t.me/${config.csUsername}`)]
            ])
        }
    );
};

// Helper function untuk emoji status
const getStatusEmoji = (status) => {
    const emojis = {
        'Pending': '⏳',
        'Processing': '🔄',
        'Success': '✅',
        'Error': '❌',
        'Partial': '⚠️'
    };
    return emojis[status] || '❓';
};

// Helper function untuk format tanggal
const formatDate = (date) => {
    const d = new Date(date);
    return d.toLocaleString('id-ID', { 
        day: '2-digit',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
    });
};

// Export semua handler
module.exports = {
    handleRiwayat,
    handleRefill,
    handleRefillId,
    handleBalance,
    handleCS,
    handleRiwayatClose,
    handleRiwayatAction
};