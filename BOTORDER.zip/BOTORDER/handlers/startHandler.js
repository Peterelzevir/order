// handlers/startHandler.js
const { Markup } = require('telegraf');
const config = require('../config/config.json');
const { readData, writeData } = require('../helpers/fileHelper');

const mainMenu = Markup.inlineKeyboard([
  [
    Markup.button.callback('💎 Deposit', 'deposit'),
    Markup.button.callback('🛍️ Order', 'order')
  ],
  [
    Markup.button.callback('📋 List', 'list'),
    Markup.button.callback('📜 History', 'riwayat')
  ],
  [
    Markup.button.callback('♻️ Refill', 'refill'),
    Markup.button.callback('👨‍💻 CS Live', 'cs')
  ],
  [Markup.button.callback('💰 Balance', 'saldo')]
]);

const adminMenu = Markup.inlineKeyboard([
  [
    Markup.button.callback('📊 Bot Activity', 'aktifitas'),
    Markup.button.callback('📢 Broadcast', 'broadcast')
  ],
  [
    Markup.button.callback('💳 Server Balance', 'saldoserver'),
    Markup.button.callback('👥 Total Users', 'totaluser')
  ]
]);

const handleStart = async (ctx) => {
  const userId = ctx.from.id;
  const data = readData();
  
  if (config.adminIds.includes(String(userId))) {
    return handleAdminStart(ctx);
  }

  const user = data.users.find(u => u.id === userId);
  
  if (!user) {
    const welcomeMessage = 
      '╔═══════════════════╗\n' +
      '║    🌟 WELCOME     ║\n' +
      '╚═══════════════════╝\n\n' +
      `*${config.botName}*\n\n` +
      '```• Status: Not Registered```\n' +
      '```• Action: Register Required```\n\n' +
      '_Please click the button below to register_\n\n' +
      '╔═══ INFORMATION ═══╗\n' +
      '• High Quality Service\n' +
      '• 24/7 Customer Support\n' +
      '• Instant Processing\n' +
      '╚═══════════════════╝';

    return ctx.reply(
      welcomeMessage,
      Markup.inlineKeyboard([
        [Markup.button.callback('📝 Register Now', 'register')]
      ])
    );
  }

  return sendMainMenu(ctx, user);
};

const handleRegister = async (ctx) => {
  const data = readData();
  const userId = ctx.from.id;

  if (data.users.some(u => u.id === userId)) {
    await ctx.answerCbQuery('⚠️ You are already registered!');
    return ctx.deleteMessage();
  }

  const newUser = {
    id: userId,
    username: ctx.from.username || 'NoUsername',
    name: ctx.from.first_name,
    registeredAt: new Date().toISOString(),
    balance: 0
  };

  data.users.push(newUser);
  writeData(data);

  const successMessage = 
    '╔═══════════════════╗\n' +
    '║  ✅ REGISTRATION  ║\n' +
    '╚═══════════════════╝\n\n' +
    '*Account Details*\n\n' +
    '```📝 Registration Success!```\n\n' +
    `*👤 Name:* _${newUser.name}_\n` +
    `*🔰 Username:* _@${newUser.username}_\n` +
    `*📅 Date:* _${new Date(newUser.registeredAt).toLocaleString()}_\n\n` +
    '╔═════ NEXT STEP ═════╗\n' +
    '```Send /start to continue```\n' +
    '╚═══════════════════════╝';

  await ctx.reply(successMessage, { parse_mode: 'Markdown' });
  return ctx.deleteMessage();
};

const sendMainMenu = async (ctx, user) => {
  const caption = 
    '╔═══════════════════╗\n' +
    `║    ${config.botName}    ║\n` +
    '╚═══════════════════╝\n\n' +
    `*Welcome Back, ${user.name}* 👋\n\n` +
    '```📱 Account Information```\n\n' +
    `*👤 Name:* _${user.name}_\n` +
    `*🔰 Username:* _@${user.username}_\n` +
    `*💰 Balance:* _Rp ${user.balance.toLocaleString()}_\n` +
    `*📅 Registered:* _${new Date(user.registeredAt).toLocaleString()}_\n\n` +
    '╔═════ MENU ═════╗\n' +
    '```Select option below```\n' +
    '╚═════════════════╝';

  return ctx.replyWithPhoto(
    { source: config.welcomeImage },
    { caption, ...mainMenu, parse_mode: 'Markdown' }
  );
};

const handleAdminStart = async (ctx) => {
  const data = readData();
  const today = new Date().toISOString().split('T')[0];
  
  const stats = {
    totalUsers: data.users.length,
    todayOrders: 0, // Implement order tracking
    totalBalance: data.users.reduce((sum, user) => sum + user.balance, 0)
  };

  const adminMessage = 
    '╔═══════════════════╗\n' +
    '║   👑 ADMIN PANEL  ║\n' +
    '╚═══════════════════╝\n\n' +
    '*📊 Today Statistics*\n\n' +
    '```📦 Orders Information```\n' +
    `*• Total Orders:* _${stats.todayOrders}_\n` +
    `*• Total Users:* _${stats.totalUsers}_\n` +
    `*• Total Balance:* _Rp ${stats.totalBalance.toLocaleString()}_\n\n` +
    '╔═════ MENU ═════╗\n' +
    '```Select option below```\n' +
    '╚═════════════════╝';

  return ctx.reply(adminMessage, { ...adminMenu, parse_mode: 'Markdown' });
};

module.exports = {
  handleStart,
  handleRegister,
  mainMenu,
  adminMenu
};