// handlers/buttonHandler.js
const handleButton = async (ctx) => {
  const action = ctx.callbackQuery.data;
  const commands = {
    deposit: '```💎 Format: /deposit <amount>```\n\n_Example: /deposit 50000_',
    order: '```🛍️ Format: /order```\n\n_Choose service from the list_',
    list: '```📋 Format: /list```\n\n_View available services_',
    riwayat: '```📜 Format: /riwayat```\n\n_Check your order history_',
    reffil: '```♻️ Format: /refill```\n\n_Request refill for your order_',
    cs: '```👨‍💻 Format: /cs```\n\n_Contact customer service_',
    saldo: '```💰 Format: /saldo```\n\n_Check your current balance_',
    aktifitas: '```📊 Format: /aktifitas```\n\n_View bot activities_',
    broadcast: '```📢 Format: /bc```\n\n_Send broadcast message_',
    saldoserver: '```💳 Format: /saldoserver```\n\n_Check server balance_',
    totaluser: '```👥 Format: /totaluser```\n\n_View total registered users_'
  };

  if (commands[action]) {
    const message = 
      '╔═══════════════════╗\n' +
      '║   ℹ️ INFORMATION   ║\n' +
      '╚═══════════════════╝\n\n' +
      commands[action];

    return ctx.editMessageText(
      message,
      {
        parse_mode: 'Markdown',
        ...Markup.inlineKeyboard([[Markup.button.callback('🔙 Back to Menu', 'back')]])
      }
    );
  }
};