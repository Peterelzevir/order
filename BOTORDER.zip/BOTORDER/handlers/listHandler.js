const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData } = require('../helpers/fileHelper');

const ITEMS_PER_PAGE = 10;

// Function to remove duplicates and clean service names
const cleanServiceName = (name) => name.trim();

const fetchServices = async () => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        if (!response.data.status) {
            throw new Error(response.data.msg);
        }

        // Clean and deduplicate services
        const uniqueServices = [];
        const seenNames = new Set();

        response.data.data.forEach(service => {
            const cleanedName = cleanServiceName(service.name);
            if (!seenNames.has(cleanedName)) {
                seenNames.add(cleanedName);
                service.name = cleanedName;
                uniqueServices.push(service);
            }
        });

        return uniqueServices;
    } catch (error) {
        console.error('Error fetching services:', error);
        return [];
    }
};

const checkRegistration = async (ctx, next) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        
        if (!user) {
            return ctx.reply('⚠️ Anda belum terdaftar. Silakan gunakan /start terlebih dahulu.');
        }
    }
    return next();
};

// Sanitize text for button labels (max 64 chars)
const sanitizeButtonText = (text) => {
    return text.trim().substring(0, 64);
};

const handleList = async (ctx) => {
    try {
        const services = await fetchServices();
        
        if (!services) {
            return ctx.reply('❌ Gagal mengambil data layanan.');
        }

        // Get unique product names
        const productsMap = new Map();
        services.forEach(service => {
            if (service.name && typeof service.name === 'string') {
                const [productName] = service.name.split(' - ');
                const cleanName = sanitizeButtonText(productName);
                if (cleanName && !productsMap.has(cleanName)) {
                    productsMap.set(cleanName, true);
                }
            }
        });

        const products = Array.from(productsMap.keys());
        if (products.length === 0) {
            return ctx.reply('❌ Tidak ada produk yang tersedia.');
        }

        // Create keyboard layout
        const keyboard = [];
        for (let i = 0; i < products.length; i += 2) {
            const row = [];
            const product1 = products[i];
            const product2 = products[i + 1];

            if (product1) {
                row.push(Markup.button.callback(product1, `product:${product1}`));
            }
            
            if (product2) {
                row.push(Markup.button.callback(product2, `product:${product2}`));
            }

            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        if (keyboard.length > 0) {
            keyboard.push([Markup.button.callback('❌ Tutup', 'close')]);

            return ctx.reply('📋 *Pilih Produk:*', {
                parse_mode: 'Markdown',
                ...Markup.inlineKeyboard(keyboard)
            });
        } else {
            return ctx.reply('❌ Tidak ada produk yang tersedia.');
        }
    } catch (error) {
        console.error('Error in handleList:', error);
        return ctx.reply('❌ Terjadi kesalahan saat memuat daftar produk.');
    }
};

const handleListNavigation = async (ctx) => {
    try {
        const product = ctx.callbackQuery.data.split(':')[1];
        if (!product) throw new Error('Invalid product');

        const services = await fetchServices();
        if (!services) throw new Error('Failed to fetch services');

        // Get unique catalogs
        const catalogsMap = new Map();
        services.forEach(service => {
            if (service.name && service.name.startsWith(product)) {
                const parts = service.name.split(' - ');
                if (parts[1]) {
                    const cleanCatalog = sanitizeButtonText(parts[1]);
                    if (cleanCatalog) {
                        catalogsMap.set(cleanCatalog, true);
                    }
                }
            }
        });

        const catalogs = Array.from(catalogsMap.keys());
        if (catalogs.length === 0) {
            await ctx.answerCbQuery();
            return ctx.reply('❌ Tidak ada katalog untuk produk ini.');
        }

        // Create keyboard layout
        const keyboard = [];
        for (let i = 0; i < catalogs.length; i += 2) {
            const row = [];
            const catalog1 = catalogs[i];
            const catalog2 = catalogs[i + 1];

            if (catalog1) {
                row.push(Markup.button.callback(catalog1, `catalog:${product}:${catalog1}`));
            }
            
            if (catalog2) {
                row.push(Markup.button.callback(catalog2, `catalog:${product}:${catalog2}`));
            }

            if (row.length > 0) {
                keyboard.push(row);
            }
        }

        keyboard.push([
            Markup.button.callback('⬅️ Kembali', 'list'),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        await ctx.answerCbQuery();
        return ctx.editMessageText(`📂 *Pilih Katalog untuk ${product}:*`, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleListNavigation:', error);
        await ctx.answerCbQuery();
        return ctx.reply('❌ Terjadi kesalahan saat memuat katalog.');
    }
};

const handleServiceList = async (ctx) => {
    try {
        const [_, product, catalog, pageStr = '0'] = ctx.callbackQuery.data.split(':');
        if (!product || !catalog) throw new Error('Invalid product or catalog');

        const services = await fetchServices();
        if (!services) throw new Error('Failed to fetch services');

        // Filter and deduplicate services
        const seenServices = new Set();
        const filteredServices = services.filter(service => {
            if (service.name && service.name.startsWith(`${product} - ${catalog}`)) {
                if (!seenServices.has(service.name)) {
                    seenServices.add(service.name);
                    return true;
                }
            }
            return false;
        });

        if (filteredServices.length === 0) {
            await ctx.answerCbQuery();
            return ctx.reply('❌ Tidak ada layanan yang tersedia.');
        }

        // Pagination
        const currentPage = Math.max(0, parseInt(pageStr) || 0);
        const totalPages = Math.ceil(filteredServices.length / ITEMS_PER_PAGE);
        const startIndex = currentPage * ITEMS_PER_PAGE;
        const endIndex = Math.min(startIndex + ITEMS_PER_PAGE, filteredServices.length);
        const pageServices = filteredServices.slice(startIndex, endIndex);

        // Build message
        let message = `📌 *Layanan ${catalog} - ${product}:*\n\n`;
        pageServices.forEach(service => {
            const markup = (100 + config.margin) / 100;
            const adjustedPrice = service.price * markup;
            
            message += `📍 *ID:* ${service.id}\n`;
            message += `💡 *Nama:* ${service.name}\n`;
            message += `💰 *Harga:* Rp ${adjustedPrice.toLocaleString()}/1000\n`;
            message += `📊 *Min/Max:* ${service.min}/${service.max}\n`;
            message += `♻️ *Refill:* ${service.refill ? '✅' : '❌'}\n\n`;
        });

        // Navigation buttons
        const keyboard = [];
        const navigationRow = [];

        if (currentPage > 0) {
            navigationRow.push(Markup.button.callback('⬅️ Sebelumnya', `catalog:${product}:${catalog}:${currentPage - 1}`));
        }

        if (currentPage < totalPages - 1) {
            navigationRow.push(Markup.button.callback('Selanjutnya ➡️', `catalog:${product}:${catalog}:${currentPage + 1}`));
        }

        if (navigationRow.length > 0) {
            keyboard.push(navigationRow);
        }

        keyboard.push([
            Markup.button.callback('⬅️ Katalog', `product:${product}`),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        await ctx.answerCbQuery();
        return ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleServiceList:', error);
        await ctx.answerCbQuery();
        return ctx.reply('❌ Terjadi kesalahan saat memuat layanan.');
    }
};

const handleClose = async (ctx) => {
    try {
        await ctx.answerCbQuery();
        await ctx.deleteMessage();
    } catch (error) {
        console.error('Error in handleClose:', error);
    }
};

module.exports = {
    handleList,
    handleListNavigation,
    handleClose,
    handleServiceList,
    fetchServices,
    checkRegistration,
    cleanServiceName,
    sanitizeButtonText
};