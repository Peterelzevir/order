const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData } = require('../helpers/fileHelper');

const ITEMS_PER_PAGE = 10;

// Fungsi untuk mengambil layanan dari API
const fetchServices = async () => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        if (!response.data.status) {
            throw new Error(response.data.msg);
        }

        return response.data.data;
    } catch (error) {
        console.error('Error fetching services:', error);
        return [];
    }
};

// **Middleware untuk cek registrasi user**
const checkRegistration = async (ctx, next) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        
        if (!user) {
            return ctx.reply(
                '⚠️ Anda belum terdaftar. Silakan gunakan /start terlebih dahulu.',
                { parse_mode: 'Markdown' }
            );
        }
    }
    return next();
};

// **LANGKAH 1: Menampilkan Produk**
const handleList = async (ctx) => {
    const services = await fetchServices();
    if (services.length === 0) {
        return ctx.reply('❌ Gagal mengambil data layanan.');
    }

    const products = [...new Set(services.map(service => service.name.split(' - ')[0]))];

    const buttons = products.map(product => Markup.button.callback(product, `product:${product}`));
    buttons.push(Markup.button.callback('❌ Tutup', 'close'));

    return ctx.reply('📋 *Pilih Produk:*', {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard(buttons, { columns: 2 })
    });
};

// **LANGKAH 2: Menampilkan Katalog dari Produk yang Dipilih**
const handleListNavigation = async (ctx) => {
    const product = ctx.callbackQuery.data.split(':')[1];
    const services = await fetchServices();
    
    const catalogs = [...new Set(
        services
            .filter(service => service.name.startsWith(product))
            .map(service => service.name.split(' - ')[1])
    )];

    const buttons = catalogs.map(catalog => Markup.button.callback(catalog, `catalog:${product}:${catalog}`));
    buttons.push(Markup.button.callback('⬅️ Kembali', 'list'));
    buttons.push(Markup.button.callback('❌ Tutup', 'close'));

    await ctx.answerCbQuery();
    return ctx.editMessageText(`📂 *Pilih Katalog untuk ${product}:*`, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard(buttons, { columns: 2 })
    });
};

// **LANGKAH 3: Menampilkan Layanan dari Katalog yang Dipilih**
const handleServiceList = async (ctx) => {
    const [_, product, catalog, page = 0] = ctx.callbackQuery.data.split(':');
    const services = await fetchServices();
    
    const filteredServices = services.filter(service => service.name.startsWith(`${product} - ${catalog}`));
    
    const totalPages = Math.ceil(filteredServices.length / ITEMS_PER_PAGE);
    const currentPage = parseInt(page);
    const start = currentPage * ITEMS_PER_PAGE;
    const end = start + ITEMS_PER_PAGE;
    const pageServices = filteredServices.slice(start, end);

    let message = `📌 *Layanan ${catalog} - ${product}:*\n\n`;

    pageServices.forEach(service => {
        const markup = (100 + config.margin) / 100;
        const adjustedPrice = service.price * markup;
        
        message += `📍 *ID:* ${service.id}\n`;
        message += `💡 *Nama:* ${service.name}\n`;
        message += `💰 *Harga:* Rp ${adjustedPrice.toLocaleString()}/1000\n`;
        message += `📊 *Min/Max:* ${service.min}/${service.max}\n`;
        message += `♻️ *Refill:* ${service.refill ? '✅' : '❌'}\n\n`;
    });

    const buttons = [];
    if (currentPage > 0) {
        buttons.push(Markup.button.callback('⬅️ Sebelumnya', `catalog:${product}:${catalog}:${currentPage - 1}`));
    }
    if ((currentPage + 1) * ITEMS_PER_PAGE < filteredServices.length) {
        buttons.push(Markup.button.callback('Selanjutnya ➡️', `catalog:${product}:${catalog}:${currentPage + 1}`));
    }

    buttons.push(Markup.button.callback('⬅️ Katalog', `product:${product}`));
    buttons.push(Markup.button.callback('❌ Tutup', 'close'));

    await ctx.answerCbQuery();
    return ctx.editMessageText(message, {
        parse_mode: 'Markdown',
        reply_markup: Markup.inlineKeyboard(buttons, { columns: 2 })
    });
};

// **Handler untuk menutup pesan**
const handleClose = async (ctx) => {
    await ctx.answerCbQuery();
    try {
        await ctx.deleteMessage();
    } catch (error) {
        console.error('Gagal menghapus pesan:', error);
    }
};

// **Register action handler dengan middleware cek registrasi**
const setupListHandlers = (bot) => {
    bot.command('list', checkRegistration, handleList);
    bot.action(/^list$/, checkRegistration, handleList);
    bot.action(/^product:(.+)$/, checkRegistration, handleListNavigation);
    bot.action(/^catalog:(.+):(.+)(?::(\d+))?$/, checkRegistration, handleServiceList);
    bot.action(/^close$/, handleClose);
};

module.exports = { setupListHandlers, handleList, handleListNavigation, handleClose, handleServiceList, fetchServices, checkRegistration };