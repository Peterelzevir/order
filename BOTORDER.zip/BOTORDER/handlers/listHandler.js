const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData } = require('../helpers/fileHelper');

const ITEMS_PER_PAGE = 10;

// Function to remove duplicates and clean service names
const cleanServiceName = (name) => name.trim();

const fetchServices = async () => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        if (!response.data.status) {
            throw new Error(response.data.msg);
        }

        // Clean and deduplicate services
        const uniqueServices = [];
        const seenNames = new Set();

        response.data.data.forEach(service => {
            const cleanedName = cleanServiceName(service.name);
            if (!seenNames.has(cleanedName)) {
                seenNames.add(cleanedName);
                service.name = cleanedName;
                uniqueServices.push(service);
            }
        });

        return uniqueServices;
    } catch (error) {
        console.error('Error fetching services:', error);
        return [];
    }
};

const checkRegistration = async (ctx, next) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        
        if (!user) {
            return ctx.reply('⚠️ Anda belum terdaftar. Silakan gunakan /start terlebih dahulu.');
        }
    }
    return next();
};

const handleList = async (ctx) => {
    try {
        const services = await fetchServices();
        
        if (!services || services.length === 0) {
            return ctx.reply('❌ Gagal mengambil data layanan.');
        }

        // Get unique categories
        const categories = Array.from(new Set(services.map(service => service.category)));

        // Create keyboard layout for categories (single column)
        const keyboard = categories.map(category => ([
            Markup.button.callback(category, `cat:${category}`)
        ]));

        keyboard.push([Markup.button.callback('❌ Tutup', 'close')]);

        return ctx.reply('📋 *Pilih Kategori:*', {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleList:', error);
        return ctx.reply('❌ Terjadi kesalahan saat memuat kategori.');
    }
};

const handleCategoryProducts = async (ctx) => {
    try {
        const category = ctx.callbackQuery.data.split(':')[1];
        if (!category) throw new Error('Invalid category');

        const services = await fetchServices();
        if (!services || services.length === 0) throw new Error('Failed to fetch services');

        // Get unique product names for the selected category
        const products = Array.from(new Set(
            services
                .filter(service => service.category === category)
                .map(service => service.name)
        ));

        // Create keyboard layout for products (2 columns)
        const keyboard = [];
        for (let i = 0; i < products.length; i += 2) {
            const row = [];
            if (products[i]) {
                row.push(Markup.button.callback(products[i], `prod:${category}:${products[i]}`));
            }
            if (i + 1 < products.length) {
                row.push(Markup.button.callback(products[i + 1], `prod:${category}:${products[i + 1]}`));
            }
            keyboard.push(row);
        }

        keyboard.push([
            Markup.button.callback('⬅️ Kategori', 'list'),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        await ctx.answerCbQuery();
        return ctx.editMessageText(`📂 *Pilih Layanan ${category}:*`, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleCategoryProducts:', error);
        await ctx.answerCbQuery();
        return ctx.reply('❌ Terjadi kesalahan saat memuat layanan.');
    }
};

const handleServiceDetails = async (ctx) => {
    try {
        const [_, category, productName] = ctx.callbackQuery.data.split(':');
        if (!category || !productName) throw new Error('Invalid category or product');

        const services = await fetchServices();
        if (!services || services.length === 0) throw new Error('Failed to fetch services');

        // Find the specific service
        const service = services.find(s => 
            s.category === category && s.name === productName
        );

        if (!service) {
            await ctx.answerCbQuery();
            return ctx.reply('❌ Layanan tidak ditemukan.');
        }

        const markup = (100 + config.margin) / 100;
        const adjustedPrice = service.price * markup;

        let message = `📌 *Detail Layanan:*\n\n`;
        message += `📍 *ID:* ${service.id}\n`;
        message += `💡 *Nama:* ${service.name}\n`;
        message += `💰 *Harga:* Rp ${adjustedPrice.toLocaleString()}/1000\n`;
        message += `📊 *Min/Max:* ${service.min}/${service.max}\n`;
        message += `♻️ *Refill:* ${service.refill ? '✅' : '❌'}\n`;
        message += `⏱ *Estimasi:* ${service.average_time}\n`;
        message += `📝 *Deskripsi:* ${service.description}\n`;

        const keyboard = [
            [Markup.button.callback('⬅️ Kembali', `cat:${category}`)],
            [Markup.button.callback('❌ Tutup', 'close')]
        ];

        await ctx.answerCbQuery();
        return ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleServiceDetails:', error);
        await ctx.answerCbQuery();
        return ctx.reply('❌ Terjadi kesalahan saat memuat detail layanan.');
    }
};

const handleClose = async (ctx) => {
    try {
        await ctx.answerCbQuery();
        await ctx.deleteMessage();
    } catch (error) {
        console.error('Error in handleClose:', error);
    }
};

module.exports = {
    handleList,
    handleCategoryProducts,
    handleClose,
    handleServiceDetails,
    fetchServices,
    checkRegistration,
    cleanServiceName,
    sanitizeButtonText
};