const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');

const handleList = async (ctx) => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });
        
        if (!response.data.status) {
            throw new Error(response.data.msg);
        }
        
        const services = response.data.data;
        const ITEMS_PER_PAGE = 10;
        let currentPage = 0;
        
        if (ctx.callbackQuery && ctx.callbackQuery.data) {
            currentPage = parseInt(ctx.callbackQuery.data.split(':')[1]);
        }

        const formatServices = (page) => {
            const start = page * ITEMS_PER_PAGE;
            const end = start + ITEMS_PER_PAGE;
            const pageServices = services.slice(start, end);
            
            let message = 
                '╔═══════════════════╗\n' +
                '║   📋 LAYANAN     ║\n' +
                '╚═══════════════════╝\n\n';

            pageServices.forEach(service => {
                const markup = (100 + config.margin) / 100;
                const adjustedPrice = service.price * markup;
                
                message += 
                    `📍 *ID: ${service.id}*\n` +
                    `📦 *PRODUK: ${service.name}*\n` +
                    `📱 Kategori: ${service.category}\n` +
                    `💰 Harga: Rp ${adjustedPrice.toLocaleString()}/1000\n` +
                    `📊 Min/Max: ${service.min}/${service.max}\n` +
                    `♻️ Refill: ${service.refill ? '✅' : '❌'}\n\n`;
            });

            const totalPages = Math.ceil(services.length / ITEMS_PER_PAGE);
            message += 
                '╔═════ INFO ═════╗\n' +
                `Halaman ${page + 1} dari ${totalPages}\n` +
                '╚════════════════╝';

            const buttons = [];
            if (page > 0) {
                buttons.push(Markup.button.callback('⬅️ Sebelumnya', `list:${page-1}`));
            }
            if ((page + 1) * ITEMS_PER_PAGE < services.length) {
                buttons.push(Markup.button.callback('Selanjutnya ➡️', `list:${page+1}`));
            }

            return {
                message,
                buttons: buttons.length ? [buttons] : []
            };
        };

        const { message, buttons } = formatServices(currentPage);

        const keyboard = [
            ...buttons,
            [Markup.button.callback('🔙 Kembali', 'back')]
        ];

        if (ctx.callbackQuery) {
            try {
                await ctx.editMessageCaption(message, {
                    parse_mode: 'Markdown',
                    reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
                });
            } catch (err) {
                // If message is not modified, we don't need to throw an error
                if (err.description !== 'Bad Request: message is not modified') {
                    throw err;
                }
            }
            return;
        }
        
        return ctx.reply(message, {
            parse_mode: 'Markdown',
            reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
        });
    } catch (error) {
        console.error('List service error:', error);
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║    ❌ GAGAL      ║\n' +
            '╚═══════════════════╝\n\n' +
            'Gagal mengambil daftar layanan.\n' +
            'Silahkan coba lagi nanti atau hubungi admin.\n\n' +
            `👨‍💻 Admin: @${config.csUsername}`,
            {
                parse_mode: 'Markdown',
                reply_markup: Markup.inlineKeyboard([
                    [
                        Markup.button.callback('🔄 Coba Lagi', 'list'),
                        Markup.button.callback('🔙 Kembali', 'back')
                    ]
                ]).reply_markup
            }
        );
    }
};

// Handler untuk button navigasi list
const handleListNavigation = async (ctx) => {
    await ctx.answerCbQuery(); // Acknowledge the callback query
    return handleList(ctx);
};

module.exports = { 
    handleList,
    handleListNavigation
};