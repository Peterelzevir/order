const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');
const { readData } = require('../helpers/fileHelper');

const ITEMS_PER_PAGE = 10;

// Function to remove duplicates and clean service names
const cleanServiceName = (name) => name.trim();

const fetchServices = async () => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 0
        });

        if (!response.data.status) {
            throw new Error(response.data.msg);
        }

        // Clean and deduplicate services
        const uniqueServices = [];
        const seenNames = new Set();

        response.data.data.forEach(service => {
            const cleanedName = cleanServiceName(service.name);
            if (!seenNames.has(cleanedName)) {
                seenNames.add(cleanedName);
                service.name = cleanedName;
                uniqueServices.push(service);
            }
        });

        return uniqueServices;
    } catch (error) {
        console.error('Error fetching services:', error);
        return [];
    }
};

const checkRegistration = async (ctx, next) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        const data = readData();
        const user = data.users.find(u => u.id === ctx.from.id);
        
        if (!user) {
            return ctx.reply('⚠️ Anda belum terdaftar. Silakan gunakan /start terlebih dahulu.');
        }
    }
    return next();
};

const handleList = async (ctx) => {
    try {
        console.log('Fetching services for product list...');
        const services = await fetchServices();
        
        if (!services || services.length === 0) {
            return ctx.reply('❌ Gagal mengambil data layanan.');
        }

        // Get unique product names using Map to maintain order
        const productsMap = new Map();
        services.forEach(service => {
            const parts = service.name.split(' - ');
            const productName = parts[0].trim();
            if (!productsMap.has(productName)) {
                productsMap.set(productName, true);
            }
        });
        const products = Array.from(productsMap.keys());

        console.log('Products found:', products);

        // Create keyboard layout
        const keyboard = [];
        for (let i = 0; i < products.length; i += 2) {
            const row = [];
            row.push(Markup.button.callback(products[i], `product:${products[i]}`));
            
            if (i + 1 < products.length) {
                row.push(Markup.button.callback(products[i + 1], `product:${products[i + 1]}`));
            }
            keyboard.push(row);
        }

        // Add close button
        keyboard.push([Markup.button.callback('❌ Tutup', 'close')]);

        return ctx.reply('📋 *Pilih Produk:*', {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleList:', error);
        return ctx.reply('❌ Terjadi kesalahan saat memuat daftar produk.');
    }
};

const handleListNavigation = async (ctx) => {
    try {
        const product = ctx.callbackQuery.data.split(':')[1];
        const services = await fetchServices();
        
        // Get unique catalogs using Map
        const catalogsMap = new Map();
        services
            .filter(service => service.name.startsWith(product))
            .forEach(service => {
                const parts = service.name.split(' - ');
                if (parts[1]) {
                    const catalogName = parts[1].trim();
                    if (!catalogsMap.has(catalogName)) {
                        catalogsMap.set(catalogName, true);
                    }
                }
            });
        const catalogs = Array.from(catalogsMap.keys());

        // Create keyboard layout for catalogs
        const keyboard = [];
        for (let i = 0; i < catalogs.length; i += 2) {
            const row = [];
            row.push(Markup.button.callback(catalogs[i], `catalog:${product}:${catalogs[i]}`));
            
            if (i + 1 < catalogs.length) {
                row.push(Markup.button.callback(catalogs[i + 1], `catalog:${product}:${catalogs[i + 1]}`));
            }
            keyboard.push(row);
        }

        // Add navigation buttons
        keyboard.push([
            Markup.button.callback('⬅️ Kembali', 'list'),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        await ctx.answerCbQuery();
        return ctx.editMessageText(`📂 *Pilih Katalog untuk ${product}:*`, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleListNavigation:', error);
        await ctx.answerCbQuery();
        return ctx.reply('❌ Terjadi kesalahan saat memuat katalog.');
    }
};

const handleServiceList = async (ctx) => {
    try {
        const [_, product, catalog, page = '0'] = ctx.callbackQuery.data.split(':');
        const services = await fetchServices();
        
        // Filter services and remove duplicates
        const seenServices = new Set();
        const filteredServices = services.filter(service => {
            if (service.name.startsWith(`${product} - ${catalog}`)) {
                if (!seenServices.has(service.name)) {
                    seenServices.add(service.name);
                    return true;
                }
            }
            return false;
        });
        
        const currentPage = parseInt(page);
        const start = currentPage * ITEMS_PER_PAGE;
        const end = start + ITEMS_PER_PAGE;
        const pageServices = filteredServices.slice(start, end);

        let message = `📌 *Layanan ${catalog} - ${product}:*\n\n`;

        pageServices.forEach(service => {
            const markup = (100 + config.margin) / 100;
            const adjustedPrice = service.price * markup;
            
            message += `📍 *ID:* ${service.id}\n`;
            message += `💡 *Nama:* ${service.name}\n`;
            message += `💰 *Harga:* Rp ${adjustedPrice.toLocaleString()}/1000\n`;
            message += `📊 *Min/Max:* ${service.min}/${service.max}\n`;
            message += `♻️ *Refill:* ${service.refill ? '✅' : '❌'}\n\n`;
        });

        // Create keyboard for service list
        const keyboard = [];
        const navigationRow = [];

        if (currentPage > 0) {
            navigationRow.push(Markup.button.callback('⬅️ Sebelumnya', `catalog:${product}:${catalog}:${currentPage - 1}`));
        }

        if ((currentPage + 1) * ITEMS_PER_PAGE < filteredServices.length) {
            navigationRow.push(Markup.button.callback('Selanjutnya ➡️', `catalog:${product}:${catalog}:${currentPage + 1}`));
        }

        if (navigationRow.length > 0) {
            keyboard.push(navigationRow);
        }

        keyboard.push([
            Markup.button.callback('⬅️ Katalog', `product:${product}`),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        await ctx.answerCbQuery();
        return ctx.editMessageText(message, {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleServiceList:', error);
        await ctx.answerCbQuery();
        return ctx.reply('❌ Terjadi kesalahan saat memuat layanan.');
    }
};

const handleClose = async (ctx) => {
    try {
        await ctx.answerCbQuery();
        await ctx.deleteMessage();
    } catch (error) {
        console.error('Error in handleClose:', error);
    }
};

module.exports = {
    handleList,
    handleListNavigation,
    handleClose,
    handleServiceList,
    fetchServices,
    checkRegistration,
    cleanServiceName
};