const fs = require('fs');
const config = require('../config/config.json');
const { readData, writeData } = require('../helpers/fileHelper');

const handleBan = async (ctx) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        return ctx.reply('⛔ Akses ditolak');
    }

    await ctx.reply(
        '╔═══════════════════╗\n' +
        '║    🚫 *BAN USER*   ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Masukkan User ID yang akan di-ban:*\n' +
        'Ketik /cancel untuk membatalkan',
        { parse_mode: 'Markdown' }
    );

    const data = readData();
    const admin = data.users.find(u => u.id === ctx.from.id);
    user.state = 'AWAITING_BAN_ID';
    writeData(data);
};

const handleBanId = async (ctx) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        return ctx.reply('⛔ Akses ditolak');
    }

    const userId = ctx.message.text;
    
    if (userId.toLowerCase() === '/cancel') {
        const data = readData();
        const admin = data.users.find(u => u.id === ctx.from.id);
        delete admin.state;
        writeData(data);
        
        return ctx.reply('✅ Proses ban dibatalkan.');
    }

    const data = readData();
    const targetUser = data.users.find(u => u.id === parseInt(userId));

    if (!targetUser) {
        return ctx.reply('❌ User tidak ditemukan');
    }

    if (config.adminIds.includes(String(userId))) {
        return ctx.reply('❌ Tidak dapat mem-ban admin');
    }

    if (!config.bannedUsers) {
        config.bannedUsers = [];
    }

    if (config.bannedUsers.includes(userId)) {
        return ctx.reply('❌ User sudah dalam status banned');
    }

    config.bannedUsers.push(userId);
    fs.writeFileSync('./config/config.json', JSON.stringify(config, null, 2));

    // Clear admin state
    const admin = data.users.find(u => u.id === ctx.from.id);
    delete admin.state;
    writeData(data);

    // Notify banned user
    try {
        await ctx.telegram.sendMessage(
            parseInt(userId),
            '🚫 Akun Anda telah di-ban dari menggunakan bot.\n' +
            `Hubungi admin @${config.csUsername} untuk informasi lebih lanjut.`
        );
    } catch (error) {
        // Ignore notification error
    }

    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   ✅ *BERHASIL*   ║\n' +
        '╚═══════════════════╝\n\n' +
        '🚫 *User Berhasil Di-ban*\n\n' +
        `*ID:* ${userId}\n` +
        `*Nama:* ${targetUser.name}\n` +
        `*Username:* @${targetUser.username}`,
        { parse_mode: 'Markdown' }
    );
}; // Added missing closing brace here

const handleUnban = async (ctx) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        return ctx.reply('⛔ Akses ditolak');
    }

    await ctx.reply(
        '╔═══════════════════╗\n' +
        '║   🔓 *UNBAN USER*  ║\n' +
        '╚═══════════════════╝\n\n' +
        '*Masukkan User ID yang akan di-unban:*\n' +
        'Ketik /cancel untuk membatalkan',
        { parse_mode: 'Markdown' }
    );

    const data = readData();
    const admin = data.users.find(u => u.id === ctx.from.id);
    user.state = 'AWAITING_UNBAN_ID';
    writeData(data);
};

const handleUnbanId = async (ctx) => {
    if (!config.adminIds.includes(String(ctx.from.id))) {
        return ctx.reply('⛔ Akses ditolak');
    }

    const userId = ctx.message.text;
    
    if (userId.toLowerCase() === '/cancel') {
        const data = readData();
        const admin = data.users.find(u => u.id === ctx.from.id);
        delete admin.state;
        writeData(data);
        
        return ctx.reply('✅ Proses unban dibatalkan.');
    }

    if (!config.bannedUsers || !config.bannedUsers.includes(userId)) {
        return ctx.reply('❌ User tidak dalam status banned');
    }

    config.bannedUsers = config.bannedUsers.filter(id => id !== userId);
    fs.writeFileSync('./config/config.json', JSON.stringify(config, null, 2));

    // Clear admin state
    const data = readData();
    const admin = data.users.find(u => u.id === ctx.from.id);
    delete admin.state;
    writeData(data);

    const targetUser = data.users.find(u => u.id === parseInt(userId));

    // Notify unbanned user
    try {
        await ctx.telegram.sendMessage(
            parseInt(userId),
            '✅ Akun Anda telah di-unban.\n' +
            'Sekarang Anda dapat menggunakan bot kembali.'
        );
    } catch (error) {
        // Ignore notification error
    }

    return ctx.reply(
        '╔═══════════════════╗\n' +
        '║   ✅ *BERHASIL*   ║\n' +
        '╚═══════════════════╝\n\n' +
        '🔓 *User Berhasil Di-unban*\n\n' +
        `*ID:* ${userId}\n` +
        `*Nama:* ${targetUser && targetUser.name ? targetUser.name : 'Unknown'}\n` +
        `*Username:* @${targetUser && targetUser.username ? targetUser.username : 'Unknown'}`,
        { parse_mode: 'Markdown' }
    );
};

// Middleware untuk cek status banned
const checkBanned = async (ctx, next) => {
    // Skip check for admin commands
    if (ctx.message && ctx.message.text && ctx.message.text.startsWith('/') && 
        ['ban', 'unban', 'broadcast', 'totaluser', 'saldoserver', 'tambahsaldo', 'aktifitas']
        .some(cmd => ctx.message.text.startsWith('/' + cmd))) {
        return next();
    }

    // Skip for admins
    if (config.adminIds.includes(String(ctx.from.id))) {
        return next();
    }

    if (config.bannedUsers && config.bannedUsers.includes(String(ctx.from.id))) {
        return ctx.reply(
            '╔═══════════════════╗\n' +
            '║    🚫 *BANNED*    ║\n' +
            '╚═══════════════════╝\n\n' +
            'Maaf, akun Anda telah di-ban dari menggunakan bot.\n' +
            `Silahkan hubungi admin @${config.csUsername}\n` +
            'untuk informasi lebih lanjut.',
            { parse_mode: 'Markdown' }
        );
    }

    return next();
};

// Helper function untuk log banned action
const logBannedAction = (userId, action, adminId) => {
    const data = readData();
    if (!data.bannedLog) {
        data.bannedLog = [];
    }

    data.bannedLog.push({
        userId,
        action, // 'ban' atau 'unban'
        adminId,
        timestamp: new Date().toISOString()
    });

    writeData(data);
};

module.exports = {
    handleBan,
    handleBanId,
    handleUnban,
    handleUnbanId,
    checkBanned
};