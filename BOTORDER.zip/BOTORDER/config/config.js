module.exports = {
  botToken: "8094595824:AAHEPuWX-WU1nYVwXDFy4ZVxH-82PqCCHO8",
  adminIds: ["5988451717"],
  welcomeImage: "./assets/bot.jpg",
  botName: "Bot by @hiyaok",
  apiId: 20576,
  apiKey: "dca23p-b3n9mz-bppyqm-g93a83-bj6ybi",
  margin: 50,
  bannedUsers: [],
  minimumDeposit: 1000,
  csUsername: "hiyaok",
  orderStates: {
    pending: "Pending",
    processing: "Processing",
    success: "Success",
    error: "Error",
    partial: "Partial"
  }
};