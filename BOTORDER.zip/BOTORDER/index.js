const { Telegraf } = require('telegraf');
const config = require('./config/config.json');
const { handleStart, handleRegister } = require('./handlers/startHandler');
const { handleDeposit } = require('./handlers/depositHandler');
const { handleList } = require('./handlers/listHandler');
const { handleOrder } = require('./handlers/orderHandler');
const { handleRiwayat, handleRefill, handleBalance, handleCS } = require('./handlers/userManagement');
const { handleServerBalance, handleTotalUsers, handleBroadcast, handleAddBalance, handleActivity } = require('./handlers/adminHandler');
const { handleBan, handleBanId, handleUnban, handleUnbanId, checkBanned } = require('./handlers/adminBanHandler');
const { readData } = require('./helpers/fileHelper');

const bot = new Telegraf(config.botToken);

// Middleware
bot.use(checkBanned);

// User commands
bot.command('start', handleStart);
bot.command('deposit', handleDeposit);
bot.command('list', handleList);
bot.command('order', handleOrder);
bot.command('riwayat', handleRiwayat);
bot.command('refill', handleRefill);
bot.command('cs', handleCS);
bot.command('saldo', handleBalance);

// Admin commands
bot.command('totaluser', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleTotalUsers(ctx);
  }
});

bot.command('saldoserver', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleServerBalance(ctx);
  }
});

bot.command('bc', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleBroadcast(ctx);
  }
});

bot.command('tambahsaldo', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleAddBalance(ctx);
  }
});

bot.command('aktifitas', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleActivity(ctx);
  }
});

bot.command('ban', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleBan(ctx);
  }
});

bot.command('unban', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleUnban(ctx);
  }
});

// Handle regular messages for state management
bot.on('message', async (ctx) => {
  const data = readData();
  const user = data.users.find(u => u.id === ctx.from.id);
  
  if (!user || !user.state) return;
  
  switch(user.state) {
    case 'AWAITING_SERVICE_ID':
      return handleOrderServiceId(ctx);
    case 'AWAITING_QUANTITY':
      return handleOrderQuantity(ctx);
    case 'AWAITING_REFILL_ID':
      return handleRefillId(ctx);
    case 'AWAITING_BROADCAST':
      return handleBroadcastMessage(ctx);
    case 'AWAITING_BAN_ID':
      return handleBanId(ctx);
    case 'AWAITING_UNBAN_ID':
      return handleUnbanId(ctx);
  }
});

// Register Action
bot.action('register', handleRegister);

// Direct routing for user actions
bot.action('deposit', handleDeposit);
bot.action('order', handleOrder);
bot.action('list', handleList);
bot.action('riwayat', handleRiwayat);
bot.action('refill', handleRefill);
bot.action('cs', handleCS);
bot.action('saldo', handleBalance);

// Admin Actions with validation
bot.action('aktifitas', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleActivity(ctx);
  }
  return ctx.answerCbQuery('⛔ Akses ditolak');
});

bot.action('broadcast', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleBroadcast(ctx);
  }
  return ctx.answerCbQuery('⛔ Akses ditolak');
});

bot.action('saldoserver', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleServerBalance(ctx);
  }
  return ctx.answerCbQuery('⛔ Akses ditolak');
});

bot.action('totaluser', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleTotalUsers(ctx);
  }
  return ctx.answerCbQuery('⛔ Akses ditolak');
});

// Back Action
bot.action('back', handleStart);

// Launch bot
bot.launch();

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));