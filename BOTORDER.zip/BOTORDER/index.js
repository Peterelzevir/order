const { Telegraf } = require('telegraf');
const config = require('./config/config.json');
const { handleStart, handleRegister, adminMenu, mainMenu } = require('./handlers/startHandler');
const { handleButton } = require('./handlers/buttonHandler');
const { handleDeposit } = require('./handlers/depositHandler');
const { handleList, handleListNavigation } = require('./handlers/listHandler');
const { handleOrder, handleOrderServiceId, handleOrderConfirmation, handleOrderTarget, handleOrderQuantity } = require('./handlers/orderHandler');
const { handleRiwayat, handleRefill, handleBalance, handleRefillId, handleCS } = require('./handlers/userManagement');
const { handleServerBalance, handleTotalUsers, handleBroadcast, handleBroadcastMessage, handleAddBalance, handleActivity } = require('./handlers/adminHandler');
const { handleBan, handleBanId, handleUnban, handleUnbanId, checkBanned } = require('./handlers/adminBanHandler');
const { readData } = require('./helpers/fileHelper');

const bot = new Telegraf(config.botToken);

// Middleware
bot.use(checkBanned);

// User commands
bot.command('start', handleStart);
bot.command('deposit', handleDeposit);
bot.command('list', handleList);
bot.command('order', handleOrder);
bot.command('riwayat', handleRiwayat);
bot.command('refill', handleRefill);
bot.command('cs', handleCS);
bot.command('saldo', handleBalance);

// Admin commands
bot.command('totaluser', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleTotalUsers(ctx);
  }
});

bot.command('saldoserver', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleServerBalance(ctx);
  }
});

bot.command('bc', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleBroadcast(ctx);
  }
});

bot.command('tambahsaldo', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleAddBalance(ctx);
  }
});

bot.command('aktifitas', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleActivity(ctx);
  }
});

bot.command('ban', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleBan(ctx);
  }
});

bot.command('unban', (ctx) => {
  if (config.adminIds.includes(String(ctx.from.id))) {
    return handleUnban(ctx);
  }
});

// Handle regular messages for state management
bot.on('message', async (ctx) => {
  const data = readData();
  const user = data.users.find(u => u.id === ctx.from.id);
  
  if (!user || !user.state) return;
  
  switch(user.state) {
    case 'AWAITING_SERVICE_ID':
      return handleOrderServiceId(ctx);
    case 'AWAITING_QUANTITY':
      return handleOrderQuantity(ctx);
    case 'AWAITING_TARGET':  // Add this new case
      return handleOrderTarget(ctx);
    case 'AWAITING_REFILL_ID':
      return handleRefillId(ctx);
    case 'AWAITING_BROADCAST':
      return handleBroadcastMessage(ctx);
    case 'AWAITING_BAN_ID':
      return handleBanId(ctx);
    case 'AWAITING_UNBAN_ID':
      return handleUnbanId(ctx);
  }
});

bot.on('callback_query', async (ctx) => {
    const data = readData();
    const user = data.users.find(u => u.id === ctx.from.id);
    
    if (!user) return ctx.answerCbQuery('⚠️ Anda belum terdaftar.');

    const action = ctx.callbackQuery.data;
    
    switch (action) {
        case 'confirm_order':
            await ctx.answerCbQuery();
            return handleOrderConfirmation(ctx);

        case 'cancel_order':
            delete user.state;
            delete user.orderData;
            writeData(data);
            await ctx.answerCbQuery('✅ Order dibatalkan.');
            return ctx.editMessageText('✅ Order telah dibatalkan.', {
                parse_mode: 'Markdown'
            });

        case 'back':
            delete user.state;
            writeData(data);
            await ctx.answerCbQuery();
            return sendMainMenu(ctx, user);

        default:
            return ctx.answerCbQuery('⚠️ Perintah tidak dikenali.');
    }
});

// Register Action
bot.action('register', handleRegister);

// Common button handler for information display
bot.action(['deposit', 'order', 'list', 'riwayat', 'refill', 'cs', 'saldo', 
            'aktifitas', 'broadcast', 'saldoserver', 'totaluser'], 
  async (ctx) => {
    // Check admin access for admin actions
    if (['aktifitas', 'broadcast', 'saldoserver', 'totaluser'].includes(ctx.callbackQuery.data)) {
      if (!config.adminIds.includes(String(ctx.from.id))) {
        return ctx.answerCbQuery('⛔ Akses ditolak');
      }
    }
    return handleButton(ctx);
  }
);

// Back Action
bot.action('back', handleStart);

// Launch bot
bot.launch();

// Enable graceful stop
process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));