/**
 * =============================================
 *             ORDER BOT SERVICE 
 * =============================================
 * 
 * A Telegram bot for managing orders and services
 * Built with Node.js and Telegraf
 * 
 * Author: @hiyaok (Telegram)
 * Version: V1
 * Source Code by @hiyaok on Telegram
 * 
 * Features:
 * - Order management 
 * - Service catalog
 * - Real-time status updates
 * - User registration
 * - Admin dashboard
 * - Order history tracking
 * 
 * =============================================
 * Created by @hiyaok
 * =============================================
 */

//module
const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');

// Utilities untuk handling data
const encodeForCallback = (str) => {
    if (!str) return '';
    // Batasi panjang string sebelum encoding
    const truncated = str.length > 50 ? str.substring(0, 50) : str;
    return Buffer.from(truncated)
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
};

const decodeFromCallback = (str) => {
    try {
        if (!str) return '';
        str = str.replace(/-/g, '+').replace(/_/g, '/');
        const pad = str.length % 4;
        if (pad) {
            str += '='.repeat(4 - pad);
        }
        return Buffer.from(str, 'base64').toString('utf-8');
    } catch (error) {
        console.error('Error decoding callback data:', error);
        return '';
    }
};

const cleanServiceName = (name) => {
    if (!name) return '👀 New Service';
    
    const maxLength = 25;
    let cleanName = name.trim()
        .replace(/[\[\](){}⟨⟩《》]/g, '') // Hapus berbagai jenis kurung
        .replace(/[^\w\s\-.,]/g, '') // Hapus karakter khusus kecuali tanda baca dasar
        .replace(/\s+/g, ' ')
        .trim();
    
    return cleanName.length > maxLength 
        ? cleanName.substring(0, maxLength - 3) + '...'
        : cleanName;
};

const escapeMarkdown = (text) => {
    return text.replace(/[-_[\]()~`>#+=|{}.!]/g, '\\$&');
};

const fetchServices = async () => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        if (!response.data.status) {
            throw new Error(response.data.msg);
        }

        const uniqueServices = [];
        const seenNames = new Set();

        response.data.data.forEach(service => {
            const cleanedName = cleanServiceName(service.name);
            if (!seenNames.has(cleanedName)) {
                seenNames.add(cleanedName);
                service.name = cleanedName;
                uniqueServices.push(service);
            }
        });

        return uniqueServices;
    } catch (error) {
        console.error('Error fetching services:', error);
        return [];
    }
};

// Handler untuk menampilkan list kategori
const handleList = async (ctx) => {
    try {
        const services = await fetchServices();
        
        if (!services || services.length === 0) {
            return ctx.reply('❌ Gagal mengambil data layanan.');
        }

        const categories = Array.from(new Set(services.map(service => service.category)))
            .filter(Boolean)
            .slice(0, 50);

        const keyboard = categories.map(category => {
            const cleanCategory = cleanServiceName(category);
            const encodedCallback = `c:${encodeForCallback(category)}:0`;
            
            // Validasi panjang callback data
            if (encodedCallback.length > 64) {
                console.error(`Callback data too long for category: ${category}`);
                return null;
            }
            
            return [Markup.button.callback(
                `✅ ${cleanCategory}`.slice(0, 30),
                encodedCallback
            )];
        }).filter(Boolean); // Hapus null values

        keyboard.push([Markup.button.callback('❌ Tutup', 'close')]);

        const message = '👀 ʜᴀʟᴏ ᴋᴀᴍᴜ ʙᴇʀᴀᴅᴀ ᴅɪ ʜᴀʟᴀᴍᴀɴ ʟɪꜱᴛ\n\n👇 ʟɪʜᴀᴛ ᴅᴜʟᴜ ʏᴜᴜᴜ ᴅɪꜱɪɴɪ\n\n📋 ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ɴʏᴀ :';

        if (ctx.callbackQuery) {
            await ctx.answerCbQuery().catch(console.error);
            return ctx.editMessageText(message, {
                reply_markup: Markup.inlineKeyboard(keyboard)
            });
        } else {
            return ctx.reply(message, {
                reply_markup: Markup.inlineKeyboard(keyboard)
            });
        }
    } catch (error) {
        console.error('Error in handleList:', error);
        const errorMsg = '❌ Terjadi kesalahan saat memuat kategori.';
        if (ctx.callbackQuery) {
            await ctx.answerCbQuery().catch(console.error);
            return ctx.editMessageText(errorMsg);
        } else {
            return ctx.reply(errorMsg);
        }
    }
};

// Handler untuk menampilkan produk dalam kategori
const handleCategoryProducts = async (ctx) => {
    try {
        const [command, encodedCategory, pageStr] = ctx.callbackQuery.data.split(':');
        const category = decodeFromCallback(encodedCategory);
        const page = parseInt(pageStr) || 0;
        
        const services = await fetchServices();
        if (!services || services.length === 0) {
            throw new Error('Failed to fetch services');
        }

        const products = services
            .filter(service => service.category === category)
            .map(service => ({
                id: service.id,
                name: cleanServiceName(service.name)
            }));

        const ITEMS_PER_PAGE = 8; // Mengurangi jumlah item per halaman
        const totalPages = Math.ceil(products.length / ITEMS_PER_PAGE);
        const startIdx = page * ITEMS_PER_PAGE;
        const endIdx = startIdx + ITEMS_PER_PAGE;
        const currentPageProducts = products.slice(startIdx, endIdx);

        const keyboard = [];
        
        // Produk buttons
        currentPageProducts.forEach(product => {
            const callback = `p:${product.id}`;
            if (callback.length <= 64) {
                keyboard.push([
                    Markup.button.callback(`✅ ${product.name}`, callback)
                ]);
            }
        });

        // Navigasi
        const navigationRow = [];
        if (page > 0) {
            navigationRow.push(Markup.button.callback(
                '⬅️ Sebelumnya',
                `c:${encodedCategory}:${page - 1}`
            ));
        }
        if (page < totalPages - 1) {
            navigationRow.push(Markup.button.callback(
                'Selanjutnya ➡️',
                `c:${encodedCategory}:${page + 1}`
            ));
        }
        if (navigationRow.length > 0) {
            keyboard.push(navigationRow);
        }

        // Menu dan tutup buttons
        keyboard.push([
            Markup.button.callback('⬅️ Menu Utama', 'list'),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        const pageInfo = totalPages > 1 ? ` (${page + 1}/${totalPages})` : '';
        const cleanCategoryName = escapeMarkdown(category);
        
        await ctx.answerCbQuery();
        return ctx.editMessageText(
            `👀 ʜᴀʟᴏ ᴋᴀᴍᴜ ʙᴇʀᴀᴅᴀ ᴅɪ ʜᴀʟᴀᴍᴀɴ ʟɪꜱᴛ\n\n👇 ʟɪʜᴀᴛ ᴅᴜʟᴜ ʏᴜᴜᴜ ᴅɪꜱɪɴɪ\n\n📋  𝗞𝗮𝗺𝘂 𝗯𝗲𝗿𝗮𝗱𝗮 𝗱𝗶 𝗞𝗮𝘁𝗲𝗴𝗼𝗿𝗶 :\n${cleanCategoryName}${pageInfo}`,
            {
                parse_mode: 'MarkdownV2',
                reply_markup: Markup.inlineKeyboard(keyboard)
            }
        );
    } catch (error) {
        console.error('Error in handleCategoryProducts:', error);
        await ctx.answerCbQuery();
        return ctx.editMessageText('❌ Terjadi kesalahan saat memuat layanan.');
    }
};

// Handler untuk menampilkan detail layanan
const handleServiceDetails = async (ctx) => {
    try {
        const [command, serviceId] = ctx.callbackQuery.data.split(':');
        
        const services = await fetchServices();
        if (!services || services.length === 0) {
            throw new Error('Failed to fetch services');
        }

        const service = services.find(s => s.id.toString() === serviceId);
        if (!service) {
            await ctx.answerCbQuery();
            return ctx.editMessageText('❌ Layanan tidak ditemukan.');
        }

        const markup = (100 + config.margin) / 100;
        const adjustedPrice = service.price * markup;

        // Escape dan bersihkan semua teks
        const escapedCategory = escapeMarkdown(service.category);
        const escapedName = escapeMarkdown(cleanServiceName(service.name));
        const escapedTime = escapeMarkdown(service.average_time || 'Tidak tersedia');
        const escapedDescription = escapeMarkdown(service.description || 'Tidak ada deskripsi');

        const message = [
            '📌 *Detail Layanan:*\n',
            `📍 *ID:* ${service.id}`,
            `💡 *Nama:* ${escapedName}`,
            `💰 *Harga:* Rp ${adjustedPrice.toLocaleString()}/1000`,
            `📊 *Min/Max:* ${service.min}/${service.max}`,
            `♻️ *Refill:* ${service.refill ? '✅' : '❌'}`,
            `⏱ *Estimasi:* ${escapedTime}`,
            `🗒 *Deskripsi:* ${escapedDescription}`
        ].join('\n');

        const keyboard = [
            [Markup.button.callback('⬅️ Kembali', `c:${encodeForCallback(service.category)}:0`)],
            [Markup.button.callback('❌ Tutup', 'close')]
        ];

        await ctx.answerCbQuery();
        return ctx.editMessageText(message, {
            parse_mode: 'MarkdownV2',
            reply_markup: Markup.inlineKeyboard(keyboard)
        });
    } catch (error) {
        console.error('Error in handleServiceDetails:', error);
        await ctx.answerCbQuery();
        return ctx.editMessageText('❌ Terjadi kesalahan saat memuat detail layanan.');
    }
};

// Handler untuk menutup menu
const handleClose = async (ctx) => {
    try {
        await ctx.answerCbQuery();
        await ctx.deleteMessage();
    } catch (error) {
        console.error('Error in handleClose:', error);
    }
};

module.exports = {
    handleList,
    handleCategoryProducts,
    handleClose,
    handleServiceDetails,
    fetchServices,
    cleanServiceName,
    encodeForCallback,
    decodeFromCallback
};