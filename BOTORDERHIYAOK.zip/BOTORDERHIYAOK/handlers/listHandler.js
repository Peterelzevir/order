/**
 * =============================================
 *             ORDER BOT SERVICE 
 * =============================================
 * 
 * A Telegram bot for managing orders and services
 * Built with Node.js and Telegraf
 * 
 * Author: @hiyaok (Telegram)
 * Version: V1
 * Source Code by @hiyaok on Telegram
 * 
 * Features:
 * - Order management 
 * - Service catalog
 * - Real-time status updates
 * - User registration
 * - Admin dashboard
 * - Order history tracking
 * 
 * =============================================
 * Created by @hiyaok
 * =============================================
 */

//module
const { Markup } = require('telegraf');
const axios = require('axios');
const config = require('../config/config.json');

const encodeForCallback = (str) => {
    return Buffer.from(str)
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
};

const decodeFromCallback = (str) => {
    str = str.replace(/-/g, '+').replace(/_/g, '/');
    const pad = str.length % 4;
    if (pad) {
        str += '='.repeat(4 - pad);
    }
    return Buffer.from(str, 'base64').toString('utf-8');
};

const cleanServiceName = (name) => {
    const maxLength = 30;
    let cleanName = name.trim()
        .replace(/\[.*?\]/g, '')
        .replace(/\(.*?\)/g, '')
        .replace(/server \d+/i, '')
        .replace(/\s+/g, ' ')
        .trim();
    
    return cleanName.length > maxLength 
        ? cleanName.substring(0, maxLength - 3) + '...'
        : cleanName;
};

const escapeMarkdown = (text) => {
    return text.replace(/[-_[\]()~`>#+=|{}.!]/g, '\\$&');
};

const fetchServices = async () => {
    try {
        const response = await axios.post('https://api.medanpedia.co.id/services', {
            api_id: config.apiId,
            api_key: config.apiKey,
            service_fav: 1
        });

        if (!response.data.status) {
            throw new Error(response.data.msg);
        }

        const uniqueServices = [];
        const seenNames = new Set();

        response.data.data.forEach(service => {
            const cleanedName = cleanServiceName(service.name);
            if (!seenNames.has(cleanedName)) {
                seenNames.add(cleanedName);
                service.name = cleanedName;
                uniqueServices.push(service);
            }
        });

        return uniqueServices;
    } catch (error) {
        console.error('Error fetching services:', error);
        return [];
    }
};

const handleList = async (ctx) => {
    try {
        const services = await fetchServices();
        
        if (!services || services.length === 0) {
            return ctx.reply('❌ Gagal mengambil data layanan.');
        }

        const categories = Array.from(new Set(services.map(service => service.category)));
        const keyboard = categories.map(category => ([
            Markup.button.callback(`✅ ${category}`, `c:${encodeForCallback(category)}:0`)
        ]));

        keyboard.push([Markup.button.callback('❌ Tutup', 'close')]);

        const message = '👀 ʜᴀʟᴏ ᴋᴀᴍᴜ ʙᴇʀᴀᴅᴀ ᴅɪ ʜᴀʟᴀᴍᴀɴ ʟɪꜱᴛ\n\n👇 ʟɪʜᴀᴛ ᴅᴜʟᴜ ʏᴜᴜᴜ ᴅɪꜱɪɴɪ\n\n📋 ᴘɪʟɪʜ ᴋᴀᴛᴇɢᴏʀɪ ɴʏᴀ :';
        
        if (ctx.callbackQuery) {
            await ctx.answerCbQuery();
            return ctx.editMessageText(message, {
                reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
            });
        } else {
            return ctx.reply(message, {
                reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
            });
        }
    } catch (error) {
        console.error('Error in handleList:', error);
        const errorMsg = '❌ Terjadi kesalahan saat memuat kategori.';
        if (ctx.callbackQuery) {
            await ctx.answerCbQuery();
            return ctx.editMessageText(errorMsg);
        } else {
            return ctx.reply(errorMsg);
        }
    }
};

const handleCategoryProducts = async (ctx) => {
    try {
        const [command, encodedCategory, pageStr] = ctx.callbackQuery.data.split(':');
        const category = decodeFromCallback(encodedCategory);
        const page = parseInt(pageStr) || 0;
        
        const services = await fetchServices();
        if (!services || services.length === 0) {
            throw new Error('Failed to fetch services');
        }

        const products = services
            .filter(service => service.category === category)
            .map(service => ({ id: service.id, name: service.name }));

        const ITEMS_PER_PAGE = 10; // Menampilkan 5 item per halaman untuk layout 1x1
        const totalPages = Math.ceil(products.length / ITEMS_PER_PAGE);
        const startIdx = page * ITEMS_PER_PAGE;
        const endIdx = startIdx + ITEMS_PER_PAGE;
        const currentPageProducts = products.slice(startIdx, endIdx);

        const keyboard = [];
        
        // Layout 1x1 untuk produk
        currentPageProducts.forEach(product => {
            keyboard.push([
                Markup.button.callback(`✅ ${product.name}`, `p:${product.id}`)
            ]);
        });

        // Tombol navigasi
        const navigationRow = [];
        if (page > 0) {
            navigationRow.push(Markup.button.callback(
                '⬅️ Sebelumnya',
                `c:${encodedCategory}:${page - 1}`
            ));
        }
        if (page < totalPages - 1) {
            navigationRow.push(Markup.button.callback(
                'Selanjutnya ➡️',
                `c:${encodedCategory}:${page + 1}`
            ));
        }
        if (navigationRow.length > 0) {
            keyboard.push(navigationRow);
        }

        // Tombol kembali dan tutup
        keyboard.push([
            Markup.button.callback('⬅️ Menu Utama', 'list'),
            Markup.button.callback('❌ Tutup', 'close')
        ]);

        const pageInfo = totalPages > 1 ? ` (${page + 1}/${totalPages})` : '';
        
        await ctx.answerCbQuery();
        return ctx.editMessageText(`👀 ʜᴀʟᴏ ᴋᴀᴍᴜ ʙᴇʀᴀᴅᴀ ᴅɪ ʜᴀʟᴀᴍᴀɴ ʟɪꜱᴛ\n\n👇 ʟɪʜᴀᴛ ᴅᴜʟᴜ ʏᴜᴜᴜ ᴅɪꜱɪɴɪ\n\n📋  𝗞𝗮𝗺𝘂 𝗯𝗲𝗿𝗮𝗱𝗮 𝗱𝗶 𝗞𝗮𝘁𝗲𝗴𝗼𝗿𝗶 :\n${escapeMarkdown(category)}${pageInfo}`, {
            parse_mode: 'MarkdownV2',
            reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
        });
    } catch (error) {
        console.error('Error in handleCategoryProducts:', error);
        await ctx.answerCbQuery();
        return ctx.editMessageText('❌ Terjadi kesalahan saat memuat layanan.');
    }
};

const handleServiceDetails = async (ctx) => {
    try {
        const [command, serviceId] = ctx.callbackQuery.data.split(':');
        
        const services = await fetchServices();
        if (!services || services.length === 0) {
            throw new Error('Failed to fetch services');
        }

        const service = services.find(s => s.id.toString() === serviceId);
        if (!service) {
            await ctx.answerCbQuery();
            return ctx.editMessageText('❌ Layanan tidak ditemukan.');
        }

        const markup = (100 + config.margin) / 100;
        const adjustedPrice = service.price * markup;

        // Escape all special characters for MarkdownV2
        const escapedCategory = escapeMarkdown(service.category);
        const escapedName = escapeMarkdown(service.name);
        const escapedTime = escapeMarkdown(service.average_time);
        const escapedDescription = escapeMarkdown(service.description);

        const message = [
            '📌 *Detail Layanan:*\n',
            `📍 *ID:* ${service.id}`,
            `💡 *Nama:* ${escapedName}`,
            `💰 *Harga:* Rp ${adjustedPrice.toLocaleString()}/1000`,
            `📊 *Min/Max:* ${service.min}/${service.max}`,
            `♻️ *Refill:* ${service.refill ? '✅' : '❌'}`,
            `⏱ *Estimasi:* ${escapedTime}`,
            `🗒 *Deskripsi:* ${escapedDescription}`
        ].join('\n');

        const keyboard = [
            [Markup.button.callback('⬅️ Kembali', `c:${encodeForCallback(service.category)}:0`)],
            [Markup.button.callback('❌ Tutup', 'close')]
        ];

        await ctx.answerCbQuery();
        return ctx.editMessageText(message, {
            parse_mode: 'MarkdownV2',
            reply_markup: Markup.inlineKeyboard(keyboard).reply_markup
        });
    } catch (error) {
        console.error('Error in handleServiceDetails:', error);
        await ctx.answerCbQuery();
        return ctx.editMessageText('❌ Terjadi kesalahan saat memuat detail layanan.');
    }
};

const handleClose = async (ctx) => {
    try {
        await ctx.answerCbQuery();
        await ctx.deleteMessage();
    } catch (error) {
        console.error('Error in handleClose:', error);
    }
};

module.exports = {
    handleList,
    handleCategoryProducts,
    handleClose,
    handleServiceDetails,
    fetchServices,
    cleanServiceName,
    encodeForCallback,
    decodeFromCallback
};